package com.sandy.chilli_souce.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.sandy.chilli_souce.R

class SplashActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splashfile)
        Handler().postDelayed({
            val loinpage= Intent(this@SplashActivity,
                LogInActivity::class.java)
            startActivity(loinpage)
            finish()


        },2000)

    }
}