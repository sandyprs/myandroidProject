package com.sandy.chilli_souce.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query


@Dao
interface FoodDao {

    @Insert
    fun foodInsert(foodEntities: FoodEntities)

    @Delete
    fun foodDelete(foodEntities: FoodEntities)
    @Query("SELECT * FROM foods")
    fun getAllFoods():List<FoodEntities>?

    @Query("SELECT * FROM foods WHERE food_id=:foodId")
    fun getById(foodId:String):FoodEntities?

}