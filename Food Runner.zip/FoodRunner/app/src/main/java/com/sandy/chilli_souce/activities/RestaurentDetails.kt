package com.sandy.chilli_souce.activities

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.adapter.Descriptionadapter
import com.sandy.chilli_souce.dataclass.Foods
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.room.Room
import com.sandy.chilli_souce.database.FoodDatabase
import com.sandy.chilli_souce.util.ConnectionManager

class RestaurentDetails : AppCompatActivity() {

    lateinit var descriptionToolbar: Toolbar
    lateinit var btnProceed:Button
    lateinit var descRecyclerView: RecyclerView
    lateinit var progressLayout:RelativeLayout
    lateinit var layoutManager: RecyclerView.LayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurent_details)

        descRecyclerView=findViewById(R.id.descRecycler)
        btnProceed=findViewById(R.id.btnproceed)
        descriptionToolbar=findViewById(R.id.descriptionToolbar)
        progressLayout=findViewById(R.id.descProgressLayout)
        progressLayout.visibility=View.VISIBLE
        layoutManager=LinearLayoutManager(this@RestaurentDetails)
        val intent=intent
        val res_id=intent.getStringExtra("restaurant_id")
        val res_name=intent.getStringExtra("restaurant_name")
        descriptionToolbar.title=res_name
        setSupportActionBar(descriptionToolbar)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        btnProceed.setOnClickListener {
            val toCartIntent=Intent(this@RestaurentDetails,CartActivity::class.java)
            toCartIntent.putExtra("res_name",res_name)
            toCartIntent.putExtra("res_id",res_id)
            startActivity(toCartIntent)
        }

        if (ConnectionManager().checkConnectivity(this@RestaurentDetails)){
        val queue= Volley.newRequestQueue(this@RestaurentDetails)
        val url="http://13.235.250.119/v2/restaurants/fetch_result/$res_id"


        val jsonObjectRequest=object : JsonObjectRequest(
            Method.GET,url,null, Response.Listener {

                //println("foods $it")

                val data=it.getJSONObject("data")
                val success=data.getBoolean("success")
                val itemList= arrayListOf<Foods>()

                if (success) {
                    progressLayout.visibility=View.GONE
                    val foodArray=data.getJSONArray("data")
                    for(i in 0 until foodArray.length())
                    {
                        val food=foodArray.getJSONObject(i)
                        val f=Foods(food.getString("id"),
                                    food.getString("name"),
                                    food.getString("cost_for_one"),
                                    food.getString("restaurant_id"))
                        itemList.add(f)
                    }
                    val descriptionadapter=Descriptionadapter(this@RestaurentDetails,itemList)
                    descRecyclerView.adapter=descriptionadapter
                    descRecyclerView.layoutManager=layoutManager


                }
                else{

                    Toast.makeText(this@RestaurentDetails,"error",
                        Toast.LENGTH_SHORT).show()


                }


            },
            Response.ErrorListener {
                Toast.makeText(this@RestaurentDetails,"some error occured,try again later",
                    Toast.LENGTH_SHORT).show()



            }){

            override fun getHeaders():MutableMap<String,String>
            {
                val headers=HashMap<String,String>()
                headers["Content-type"]="application/json"
                headers["token"]="4c90c79eae1fe0"
                return headers
            }
        }
        queue.add(jsonObjectRequest)

        }
        else
        {
            val dialog= AlertDialog.Builder(this@RestaurentDetails)

            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection Not Found")
            dialog.setPositiveButton("Open Settings"){
                    text, listner ->
                val settingIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingIntent)
                this@RestaurentDetails.finish()

            }
            dialog.setNegativeButton("Exit"){
                    text,listner->
                ActivityCompat.finishAffinity(this@RestaurentDetails)
            }

            dialog.create()
            dialog.show()

        }



    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
       if(item.itemId==android.R.id.home)
       {
           onBackPressed()
       }
        return super.onOptionsItemSelected(item)
    }

    class CartData(val context: Context):
        AsyncTask<Void, Void, Unit>() {
        val db= Room.databaseBuilder(context, FoodDatabase::class.java,"cart-db").build()
        override fun doInBackground(vararg params: Void?) {
            db.cartDao().removeAll()
        }
    }

    override fun onBackPressed() {
        CartData(applicationContext).execute().get()
        super.onBackPressed()
    }

}
