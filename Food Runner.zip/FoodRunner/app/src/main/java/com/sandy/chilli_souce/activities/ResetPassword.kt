package com.sandy.chilli_souce.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.fragments.ResetPassFragment

class ResetPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)
        title="Reset Password"
        val frag=supportFragmentManager.beginTransaction()
        frag.replace(R.id.resetFrame,ResetPassFragment()).commit()


    }
}
