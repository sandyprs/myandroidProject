package com.sandy.chilli_souce.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.navigation.NavigationView
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.fragments.*

class WelcomeActivity : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var appBarLayout: AppBarLayout
    lateinit var toolbarLayout: Toolbar
    lateinit var navigationView: NavigationView
    var previousItem:MenuItem?=null
    lateinit var sharedPreferences: SharedPreferences
    lateinit var username: TextView
    lateinit var txtemail:TextView
    lateinit var searchView: SearchView




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        title="welcome"

        drawerLayout=findViewById(R.id.drawerLayout)
        coordinatorLayout=findViewById(R.id.coordinateLayout)
        appBarLayout=findViewById(R.id.appbar)
        toolbarLayout=findViewById(R.id.toolBar)
        navigationView=findViewById(R.id.navigationView)
        searchView=findViewById(R.id.search_bar)
        sharedPreferences=getSharedPreferences(getString(R.string.preference_file), Context.MODE_PRIVATE)


        setUpToolbar()
        openHome()


        val drawerToggle=ActionBarDrawerToggle(this@WelcomeActivity,drawerLayout,
            R.string.open_drawer,
            R.string.close_drawer
        )
        drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()

        navigationView.setNavigationItemSelectedListener{
            if(previousItem !=null)
                previousItem?.isChecked=false

            it.isCheckable=true
            it.isChecked=true
            previousItem=it
            val frag=supportFragmentManager.beginTransaction()

            when(it.itemId) {
                R.id.homeItem ->openHome()
                R.id.profileItem ->{
                    frag.replace(
                        R.id.frameLayout,
                        MyProfileFragment()
                    ).commit()
                    supportActionBar?.title="My Profile"
                    searchView.visibility=View.GONE
                    drawerLayout.closeDrawers()
                }

                R.id.history ->{
                    frag.replace(
                        R.id.frameLayout,
                        OrderHistory()
                    ).commit()
                    supportActionBar?.title="Order History"
                    searchView.visibility=View.GONE
                    drawerLayout.closeDrawers()
                }



                R.id.favoriteItem ->{
                    frag.replace(
                        R.id.frameLayout,
                        Favoritefragment()
                    ).commit()
                    supportActionBar?.title="Favorite Restaurents"
                    searchView.visibility=View.GONE
                    drawerLayout.closeDrawers()
                }
                R.id.faqItem ->{
                    frag.replace(R.id.frameLayout, FAQFragment()).commit()
                    supportActionBar?.title="Frequently Asked Questions"
                    searchView.visibility=View.GONE
                    drawerLayout.closeDrawers()
                }
                R.id.logoutItem -> {
                    val alert=AlertDialog.Builder(this@WelcomeActivity)
                    alert.setTitle("Confirmation")
                    alert.setMessage("Do you really want to log out?")
                    alert.setPositiveButton("yes"){
                        text,listner ->
                        sharedPreferences.edit().remove("isLoggedin").apply()
                        val intent= Intent(this@WelcomeActivity,
                            LogInActivity::class.java)
                        startActivity(intent)
                        Toast.makeText(this@WelcomeActivity,"Loged Out",Toast.LENGTH_SHORT).show()
                        finish()

                    }
                    alert.setNegativeButton("No"){
                        text,listner ->navigationView.setCheckedItem(R.id.homeItem)
                    }
                    alert.create()
                    alert.show()
                    drawerLayout.closeDrawers()

                }

            }


            return@setNavigationItemSelectedListener true
        }

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId==android.R.id.home)
        {
            drawerLayout.openDrawer(GravityCompat.START)
            val header=navigationView.getHeaderView(0)
            username=header.findViewById(R.id.username)
            username.text=sharedPreferences.getString("name","User Name")
            txtemail=header.findViewById(R.id.userMail)
            txtemail.text=sharedPreferences.getString("email","username@example.com")
            searchView.visibility=View.VISIBLE
        }


        return super.onOptionsItemSelected(item)
    }

    fun setUpToolbar()
    {
        setSupportActionBar(toolbarLayout)
        supportActionBar?.title="Welcome"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    fun openHome()
    {
        navigationView.setCheckedItem(R.id.homeItem)
        toolbarLayout.title="Home"
        val frag=supportFragmentManager.beginTransaction()
        frag.replace(R.id.frameLayout,HomeFragment(searchView)).commit()
        drawerLayout.closeDrawers()

    }

    override fun onBackPressed() {

        val frag=supportFragmentManager.findFragmentById(R.id.frameLayout)

        if(frag !is HomeFragment)
        {
            openHome()
        }
        else
            this.finishAffinity()
    }



}


