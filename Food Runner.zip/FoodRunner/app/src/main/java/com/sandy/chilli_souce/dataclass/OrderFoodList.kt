package com.sandy.chilli_souce.dataclass

data class OrderFoodList(val foodid:String,
                        val foodname:String,
                        val foodprice:String)