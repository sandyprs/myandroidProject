package com.sandy.chilli_souce.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.dataclass.OrderFoodList
import org.json.JSONArray

class FoodListAdapter(val context: Context,val foodList:ArrayList<OrderFoodList>):RecyclerView.Adapter<FoodListAdapter.FoodListViewHolder>(){

    class FoodListViewHolder(val view:View):RecyclerView.ViewHolder(view)
    {
        var histFoodName:TextView=view.findViewById(R.id.tvHistFoodName)
        var histFoodPrice:TextView=view.findViewById(R.id.tvHistFoodPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodListViewHolder {
        val view=LayoutInflater.from(context).inflate(R.layout.child_recycler_single_row,parent,false)
        return FoodListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return foodList.size
    }

    override fun onBindViewHolder(holder: FoodListViewHolder, position: Int) {
        holder.histFoodName.text=foodList[position].foodname
        holder.histFoodPrice.text=foodList[position].foodprice
    }

}