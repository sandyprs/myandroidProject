package com.sandy.chilli_souce.activities

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.util.ConnectionManager
import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.Method

class Signup : AppCompatActivity() {
    lateinit var btnRegister: Button
    lateinit var sharedPreferences: SharedPreferences
    lateinit var etname: EditText
    lateinit var etaddress: EditText
    lateinit var etphonno: EditText
    lateinit var etemail: EditText
    lateinit var etpassword: EditText
    lateinit var etrePassword: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        title = "Sign Up"
        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file), Context.MODE_PRIVATE)
        etaddress = findViewById(R.id.etaddress)
        etemail = findViewById(R.id.etemail)
        etname = findViewById(R.id.etname)
        etphonno = findViewById(R.id.etmobile)
        etpassword = findViewById(R.id.etpassword)
        etrePassword = findViewById(R.id.etrepassword)

        val intentWelcomeActivity = Intent(this@Signup, WelcomeActivity::class.java)

        btnRegister = findViewById(R.id.btnRegister)
        btnRegister.setOnClickListener {

            btnRegister.visibility=View.INVISIBLE

            if(profileSaved())
            {
                Toast.makeText(this@Signup, "You are registered", Toast.LENGTH_LONG).show()
                startActivity(intentWelcomeActivity)
                finish()
            }
            else{
                btnRegister.visibility=View.VISIBLE
                Toast.makeText(this@Signup, "Please try again", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun profileSaved():Boolean {
        if (etpassword.text.toString() == etrePassword.text.toString()) {

            var success=false

            if(ConnectionManager().checkConnectivity(this@Signup)){

            val queue=Volley.newRequestQueue(this@Signup)
            val url="http://13.235.250.119/v2/register/fetch_result/"
            val jsonParams=JSONObject()
            val name=etname.text.toString()
            val mobile=etphonno.text.toString()
            val password=etpassword.text.toString()
            val address=etaddress.text.toString()
            val email=etemail.text.toString()

            jsonParams.put("name",name)
            jsonParams.put("mobile_number",mobile)
            jsonParams.put("password",password)
            jsonParams.put("address",address)
            jsonParams.put("email",email)


            val jsonObjectRequest=object :JsonObjectRequest(Method.POST,url,jsonParams,Response.Listener {

                val data=it.getJSONObject("data")
                success=data.getBoolean("success")
                //println("responsesign $it")

                if (success) {
                    val info=data.getJSONObject("data")

                    sharedPreferences.edit().putString("user_id",info.getString("user_id") ).apply()
                    sharedPreferences.edit().putString("name", info.getString("name") ).apply()
                    sharedPreferences.edit().putString("email", info.getString("email") ).apply()
                    sharedPreferences.edit().putString("mobile_number",info.getString("mobile_number") ).apply()
                    sharedPreferences.edit().putString("address",info.getString("address") ).apply()
                    sharedPreferences.edit().putBoolean("isLoggedin",true).apply()
                    Toast.makeText(this@Signup,"Infos saved",Toast.LENGTH_SHORT).show()


                }
                else
                {
                    Toast.makeText(this@Signup,"Infos not saved",Toast.LENGTH_SHORT).show()


                }


            },
                Response.ErrorListener {
                    Toast.makeText(this@Signup,"some error occured,try again later",Toast.LENGTH_SHORT).show()



                }){

                override fun getHeaders():MutableMap<String,String>
                {
                    val headers=HashMap<String,String>()
                    headers["Content-type"]="application/json"
                    headers["token"]="4c90c79eae1fe0"
                    return headers
                }
            }
            queue.add(jsonObjectRequest)

        }
        else
        {
            val dialog= AlertDialog.Builder(this@Signup)

            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection Not Found")
            dialog.setPositiveButton("Open Settings"){
                    text, listner ->
                val settingIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingIntent)
                this@Signup.finish()

            }
            dialog.setNegativeButton("Exit"){
                    text,listner->
                ActivityCompat.finishAffinity(this@Signup)
            }

            dialog.create()
            dialog.show()

        }


        return success


        }
        else
            Toast.makeText(this@Signup,"password missmatch",Toast.LENGTH_SHORT).show()

        return false

        }

    }

