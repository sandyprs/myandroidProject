package com.sandy.chilli_souce.fragments


import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.util.ConnectionManager
import org.json.JSONObject


class ResetPassFragment : Fragment() {

    lateinit var tvMobile: TextView
    lateinit var tvEmail: TextView
    lateinit var btnNext: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_reset_pass, container, false)
        tvEmail = view.findViewById(R.id.rgtEmail)
        tvMobile = view.findViewById(R.id.rgtmobileno)
        btnNext = view.findViewById(R.id.btnnext)
        val frag = activity!!.supportFragmentManager.beginTransaction()

        btnNext.setOnClickListener {
            btnNext.visibility = View.INVISIBLE

            if (ConnectionManager().checkConnectivity(activity as Context)) {
                val queue = Volley.newRequestQueue(activity as Context)
                val url = "http://13.235.250.119/v2/forgot_password/fetch_result/"
                val params = JSONObject()
                params.put("mobile_number", tvMobile.text.toString())
                params.put("email", tvEmail.text.toString())

                val jsonObjectRequest =
                    object : JsonObjectRequest(Method.POST, url, params, Response.Listener {

                        val data = it.getJSONObject("data")
                        if (data.getBoolean("success")) {
                            val bundle = Bundle()
                            bundle.putString("mobile_number", tvMobile.text.toString())
                            frag.replace(R.id.resetFrame, OtpFragment(bundle)).commit()

                        }
                    },
                        Response.ErrorListener {

                            Toast.makeText(activity, "server error", Toast.LENGTH_LONG).show()


                        }) {

                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["Content-type"] = "application/json"
                            headers["token"] = "4c90c79eae1fe0"
                            return headers
                        }
                    }

                queue.add(jsonObjectRequest)

            } else {
                val dialog = AlertDialog.Builder(activity)

                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection Not Found")
                dialog.setPositiveButton("Open Settings") { text, listner ->
                    val settingIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingIntent)
                    activity!!.finish()

                }
                dialog.setNegativeButton("Exit") { text, listner ->
                    ActivityCompat.finishAffinity(activity!!)
                }

                dialog.create()
                dialog.show()

            }

        }
        return view


    }
}
