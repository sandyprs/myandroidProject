package com.sandy.chilli_souce.fragments

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.adapter.OrderHistoryAdaptor
import com.sandy.chilli_souce.dataclass.OrderList
import com.sandy.chilli_souce.util.ConnectionManager
import org.json.JSONException


class OrderHistory : Fragment() {

    lateinit var parentRecyclerView: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    var orderList= arrayListOf<OrderList>()
    lateinit var recyclerAdapter:OrderHistoryAdaptor
    lateinit var prog:RelativeLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_order_history, container, false)
        parentRecyclerView=view.findViewById(R.id.parentRecycler)
        prog=view.findViewById(R.id.prog)
        prog.visibility=View.VISIBLE
        layoutManager=LinearLayoutManager(activity)
        val sharedpref=activity!!.getSharedPreferences(getString(R.string.preference_file),Context.MODE_PRIVATE)
        val user_id=sharedpref.getString("user_id",null)

        if(ConnectionManager().checkConnectivity(activity as Context)) {
        val queue=Volley.newRequestQueue(activity)
        val url="http://13.235.250.119/v2/orders/fetch_result/$user_id"

        val jsonObjectRequest=object : JsonObjectRequest(
            Request.Method.GET,url,null,
            Response.Listener {
                //println("response is $it")
                val data=it.getJSONObject("data")
                val success=data.getBoolean("success")
                if (success)
                {
                    try {
                        val jsonArray=data.getJSONArray("data")
                        for(i in 0 until jsonArray.length())
                        {
                            val jsonObj=jsonArray.getJSONObject(i)
                            val order= OrderList(
                                jsonObj.getString("restaurant_name"),
                                jsonObj.getString("order_placed_at"),
                                jsonObj.getJSONArray("food_items"))

                            orderList.add(order)
                        }
                        if (activity !=null) {
                            prog.visibility = View.GONE
                            recyclerAdapter = OrderHistoryAdaptor(activity as Context, orderList)
                            parentRecyclerView.adapter = recyclerAdapter
                            parentRecyclerView.layoutManager = layoutManager
                        }

                    }catch (ex: JSONException)
                    {
                        Toast.makeText(activity,"fetching problem", Toast.LENGTH_SHORT).show()
                    }
                }
                else
                {
                    Toast.makeText(activity,"some error occured,try again later", Toast.LENGTH_SHORT).show()

                }

            },
            Response.ErrorListener {
                Toast.makeText(activity,"some error occured,try again later", Toast.LENGTH_SHORT).show()


            }){
            override fun getHeaders():MutableMap<String,String>
            {
                val headers=HashMap<String,String>()
                headers["Content-type"]="application/json"
                headers["token"]="4c90c79eae1fe0"
                return headers
            }
        }

        queue.add(jsonObjectRequest)

        }
        else
        {
            val dialog= AlertDialog.Builder(activity)

            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection Not Found")
            dialog.setPositiveButton("Open Settings"){
                    text, listner ->
                val settingIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingIntent)
                activity!!.finish()

            }
            dialog.setNegativeButton("Exit"){
                    text,listner->
                ActivityCompat.finishAffinity(activity!!)
            }

            dialog.create()
            dialog.show()

        }





        return view
    }

}
