package com.sandy.chilli_souce.fragments


import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.activities.LogInActivity
import com.sandy.chilli_souce.util.ConnectionManager
import org.json.JSONObject


class OtpFragment(val bundle: Bundle) : Fragment() {
    lateinit var btnApply:Button
    lateinit var etOtp:TextView
    lateinit var etPass:TextView
    lateinit var etRePass:TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_otp, container, false)
        btnApply=view.findViewById(R.id.btnApply)
        etOtp=view.findViewById(R.id.etOtp)
        etPass=view.findViewById(R.id.etPass)
        etRePass=view.findViewById(R.id.etRePass)

        btnApply.setOnClickListener {

            if(etPass.text.toString()==etRePass.text.toString())
            {
                println("bundle value ${bundle.getString("mobile_number")}")

                if (ConnectionManager().checkConnectivity(activity as Context)) {
                val queue= Volley.newRequestQueue(activity as Context)
                val url="http://13.235.250.119/v2/reset_password/fetch_result/"
                val params= JSONObject()
                params.put("mobile_number",bundle.getString("mobile_number"))
                params.put("password",etPass.text.toString())
                params.put("otp",etOtp.text.toString())

                println("bundle value1 ${bundle.getString("mobile_number")}")

                val jsonObjectRequest=object : JsonObjectRequest(
                    Method.POST,url,params, Response.Listener {
                        println("forget $it")

                        val data=it.getJSONObject("data")
                        if(data.getBoolean("success"))
                        {
                            btnApply.visibility=View.INVISIBLE
                            Toast.makeText(activity,data.getString("successMessage"), Toast.LENGTH_LONG).show()
                            val intentLogInActivity=Intent(activity as Context,LogInActivity::class.java)
                            startActivity(intentLogInActivity)
                            val sharedPreferences=activity!!.getSharedPreferences(getString(R.string.preference_file), Context.MODE_PRIVATE)
                            sharedPreferences.edit().clear().apply()
                            activity!!.finish()

                        }
                    },
                    Response.ErrorListener {

                        Toast.makeText(activity,"Invalid OTP", Toast.LENGTH_LONG).show()


                    }){

                    override fun getHeaders():MutableMap<String,String>
                    {
                        val headers=HashMap<String,String>()
                        headers["Content-type"]="application/json"
                        headers["token"]="4c90c79eae1fe0"
                        return headers
                    }
                }

                queue.add(jsonObjectRequest)

            } else {
                val dialog = AlertDialog.Builder(activity)

                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection Not Found")
                dialog.setPositiveButton("Open Settings") { text, listner ->
                    val settingIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingIntent)
                    activity!!.finish()

                }
                dialog.setNegativeButton("Exit") { text, listner ->
                    ActivityCompat.finishAffinity(activity!!)
                }

                dialog.create()
                dialog.show()

            }

            }
            else
            {
                Toast.makeText(activity,"Password missmatched", Toast.LENGTH_LONG).show()

            }

        }

        return view
    }


}
