package com.sandy.chilli_souce.activities

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONObject


class LogInActivity : AppCompatActivity() {


    lateinit var phoneNo:EditText
    lateinit var password:EditText
    lateinit var btnLogIn:Button
    lateinit var txtSignUP:TextView
    lateinit var txtForget:TextView
    lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        title="Log In"

        sharedPreferences=getSharedPreferences(getString(R.string.preference_file), Context.MODE_PRIVATE)
        val isloggedin=sharedPreferences.getBoolean("isLoggedin",false)
        val intent=Intent(this@LogInActivity, WelcomeActivity::class.java)
        if (isloggedin) {
            startActivity(intent)
            finish()
        }
        phoneNo=findViewById(R.id.phno)
        password=findViewById(R.id.password)
        btnLogIn=findViewById(R.id.btnLogIn)
        txtForget=findViewById(R.id.txtForgetPass)
        txtSignUP=findViewById(R.id.txtSignUp)

        btnLogIn.setOnClickListener{
            if (phno.text != null && password.text !=null)
            {
                if (ConnectionManager().checkConnectivity(this@LogInActivity)){
                val queue=Volley.newRequestQueue(this@LogInActivity)
                val url="http://13.235.250.119/v2/login/fetch_result/"

                val jsonParams= JSONObject()
                jsonParams.put("mobile_number",phoneNo.text.toString())
                jsonParams.put("password",password.text.toString())



                val jsonObjectRequest=object : JsonObjectRequest(
                    Method.POST,url,jsonParams, Response.Listener {

                        val data=it.getJSONObject("data")
                        val success=data.getBoolean("success")

                        if (success) {
                            sharedPreferences.edit().putBoolean("isLoggedin",true).apply()
                            val info=data.getJSONObject("data")

                            sharedPreferences.edit().putString("user_id",info.getString("user_id") ).apply()
                            sharedPreferences.edit().putString("name", info.getString("name") ).apply()
                            sharedPreferences.edit().putString("email", info.getString("email") ).apply()
                            sharedPreferences.edit().putString("mobile_number",info.getString("mobile_number") ).apply()
                            sharedPreferences.edit().putString("address",info.getString("address") ).apply()
                            sharedPreferences.edit().putBoolean("isLoggedin",true).apply()
                            Toast.makeText(this@LogInActivity,"Infos saved",Toast.LENGTH_SHORT).show()

                            val intentWelcomeActivity = Intent(this@LogInActivity, WelcomeActivity::class.java)
                            startActivity(intentWelcomeActivity)
                            this.finish()
                        }
                        else{

                            Toast.makeText(this@LogInActivity,"seems to be wrong credentials",Toast.LENGTH_SHORT).show()


                        }


                    },
                    Response.ErrorListener {
                        Toast.makeText(this@LogInActivity,"some error occured,try again later",Toast.LENGTH_SHORT).show()



                    }){

                    override fun getHeaders():MutableMap<String,String>
                    {
                        val headers=HashMap<String,String>()
                        headers["Content-type"]="application/json"
                        headers["token"]="4c90c79eae1fe0"
                        return headers
                    }
                }
                queue.add(jsonObjectRequest)

                }
                else
                {
                    val dialog= AlertDialog.Builder(this@LogInActivity)

                    dialog.setTitle("Error")
                    dialog.setMessage("Internet Connection Not Found")
                    dialog.setPositiveButton("Open Settings"){
                            text, listner ->
                        val settingIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        startActivity(settingIntent)
                        this@LogInActivity.finish()

                    }
                    dialog.setNegativeButton("Exit"){
                            text,listner->
                        ActivityCompat.finishAffinity(this@LogInActivity)
                    }

                    dialog.create()
                    dialog.show()

                }



            }
            else
                Toast.makeText(this@LogInActivity,"Please provide the fields",Toast.LENGTH_LONG).show()
        }

        txtForget.setOnClickListener{
            val forgetIntent=Intent(this@LogInActivity,
                ResetPassword::class.java)
            startActivity(forgetIntent)
        }


        txtSignUP.setOnClickListener{
            val signUpIntent=Intent(this@LogInActivity, Signup::class.java)
            startActivity(signUpIntent)
            finish()

        }

    }

}
