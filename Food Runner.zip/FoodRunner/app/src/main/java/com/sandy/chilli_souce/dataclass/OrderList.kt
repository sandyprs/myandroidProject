package com.sandy.chilli_souce.dataclass

import org.json.JSONArray

data class OrderList(
    val resname:String,
    val orderDate:String,
    val foodItems: JSONArray
)