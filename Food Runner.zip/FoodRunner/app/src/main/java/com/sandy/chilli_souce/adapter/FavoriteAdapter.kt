package com.sandy.chilli_souce.adapter

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.activities.RestaurentDetails
import com.sandy.chilli_souce.database.FoodDatabase
import com.sandy.chilli_souce.database.FoodEntities
import com.squareup.picasso.Picasso


class FavoriteAdapter (val context: Context,val foodList: List<FoodEntities>):RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view=LayoutInflater.from(context).inflate(R.layout.fav_single_row,parent,false)
        return FavoriteViewHolder(view)
    }

    override fun getItemCount(): Int {
        return foodList.size
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val food = foodList[position]
        holder.foodId = food.food_id.toString()
        holder.foodName.text = food.foodName
        holder.foodPrice.text = "Rs. "+food.foodPrice
        holder.foodRating.text = food.foodRating
        Picasso.get().load(food.foodImage).into(holder.foodImage)
        holder.btnFav.setBackgroundResource(R.drawable.ic_select_fav)

        holder.btnDetails.setOnClickListener {
            val restaturentDetailsIntent= Intent(context, RestaurentDetails::class.java)
            restaturentDetailsIntent.putExtra("restaurant_id",holder.foodId)
            restaturentDetailsIntent.putExtra("restaurant_name",food.foodName)
            context.startActivity(restaturentDetailsIntent)
        }


        holder.btnFav.setOnClickListener {

            if (!FavDbAsyncTask(context, food, 1).execute().get())
            {
                val async= FavDbAsyncTask(context, food, 2).execute()
                if (async.get())
                {
                    Toast.makeText(context,"Added to Favorites",Toast.LENGTH_SHORT).show()
                    holder.btnFav.setBackgroundResource(R.drawable.ic_select_fav)
                }

                else{

                    Toast.makeText(context,"Some Error Occured at Insertion",Toast.LENGTH_SHORT).show()
                }


            }

            else{
                val async= HomeRecyclerAdapter.DbAsyncTask(context, food, 3).execute()
                if (async.get())
                {
                    Toast.makeText(context,"Removed From Favorites",Toast.LENGTH_SHORT).show()
                    holder.btnFav.setBackgroundResource(R.drawable.ic_favorites)
                }

                else{

                    Toast.makeText(context,"Some Error Occured at Removing",Toast.LENGTH_SHORT).show()
                }

            }

        }
    }


        class FavoriteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            lateinit var foodId: String
            val foodName: TextView = view.findViewById(R.id.tvFavFoodName)
            val foodPrice: TextView = view.findViewById(R.id.tvFavPrice)
            val foodRating: TextView = view.findViewById(R.id.tvFavRating)
            val foodImage: ImageView = view.findViewById(R.id.imgFavfood)
            val btnFav: TextView = view.findViewById(R.id.addSelectFav)
            val btnDetails:RelativeLayout=view.findViewById(R.id.tvRelativeLayout)

        }

        class FavDbAsyncTask(val context: Context, val foodEntities: FoodEntities, val mode: Int) :
            AsyncTask<Void, Void, Boolean>() {

            override fun doInBackground(vararg params: Void?): Boolean {
                val db = Room.databaseBuilder(context, FoodDatabase::class.java, "foods-db").build()
                when (mode) {
                    1 -> {

                        val isPresent: FoodEntities? =
                            db.foodDao().getById(foodEntities.food_id.toString())
                        db.close()

                        return isPresent != null
                    }

                    2 -> {
                        db.foodDao().foodInsert(foodEntities)
                        db.close()
                        return true

                    }

                    3 -> {
                        db.foodDao().foodDelete(foodEntities)
                        db.close()
                        return true

                    }

                }
                return false
            }


        }
    }

