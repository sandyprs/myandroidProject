package com.sandy.chilli_souce.database

import androidx.room.Database
import androidx.room.RoomDatabase



@Database(entities = [FoodEntities::class,CartEntities::class],version = 1)
abstract class FoodDatabase : RoomDatabase(){
    abstract fun foodDao():FoodDao
    abstract fun cartDao():CartDao



}