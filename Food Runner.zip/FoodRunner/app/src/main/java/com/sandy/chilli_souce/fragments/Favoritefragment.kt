package com.sandy.chilli_souce.fragments


import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.adapter.FavoriteAdapter
import com.sandy.chilli_souce.database.FoodDatabase
import com.sandy.chilli_souce.database.FoodEntities
import kotlinx.android.synthetic.main.fragment_favoritefragment.*


class Favoritefragment : Fragment() {
    lateinit var favoriteAdapter: FavoriteAdapter
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerviewFav: RecyclerView
    lateinit var progress: RelativeLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_favoritefragment, container, false)
        recyclerviewFav=view.findViewById(R.id.recyclerviewFav)
        progress=view.findViewById(R.id.progressLayoutFav)
        progress.visibility=View.VISIBLE


        val favFoodList=FavasyncTask(activity as Context).execute().get()
        //println(favFoodList)
        if (favFoodList !=null)
        {
            if (activity != null) {
                favoriteAdapter = FavoriteAdapter(activity as Context, favFoodList)
                layoutManager = LinearLayoutManager(activity)
                progress.visibility=View.GONE
                recyclerviewFav.layoutManager=layoutManager
                recyclerviewFav.adapter=favoriteAdapter
            }


        }

        else
        {
            Toast.makeText(activity,"Nothing in Favorites",Toast.LENGTH_LONG).show()
        }


        return view
    }

    class FavasyncTask(val context: Context):AsyncTask<Void,Void,List<FoodEntities>>() {
        override fun doInBackground(vararg params: Void?): List<FoodEntities>? {
            val db=Room.databaseBuilder(context,FoodDatabase::class.java,"foods-db").build()
            return db.foodDao().getAllFoods()

        }
    }


}
