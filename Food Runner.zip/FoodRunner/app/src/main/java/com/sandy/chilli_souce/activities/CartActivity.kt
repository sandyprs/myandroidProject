package com.sandy.chilli_souce.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.adapter.CartAdapter
import com.sandy.chilli_souce.adapter.HomeRecyclerAdapter
import com.sandy.chilli_souce.database.CartEntities
import com.sandy.chilli_souce.database.FoodDatabase
import com.sandy.chilli_souce.dataclass.Restaurents
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class CartActivity : AppCompatActivity() {

    lateinit var orderLayout:RelativeLayout
    lateinit var btnOrderPlace:Button
    lateinit var btnOrderOk:Button
    lateinit var cartToolbar: Toolbar
    lateinit var cartRecyclerView: RecyclerView
    lateinit var tvResName:TextView
    lateinit var emptyCart:RelativeLayout
    var itemList= listOf<CartEntities>()
    lateinit var layoutManager:RecyclerView.LayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        orderLayout=findViewById(R.id.orderLayout)
        orderLayout.visibility=View.INVISIBLE
        btnOrderOk=findViewById(R.id.btnorderOk)
        btnOrderPlace=findViewById(R.id.btnOrderPlace)
        cartRecyclerView=findViewById(R.id.cartRecycler)
        layoutManager=LinearLayoutManager(this@CartActivity)
        tvResName=findViewById(R.id.tvResName)
        emptyCart=findViewById(R.id.emptyCart)
        emptyCart.visibility=View.INVISIBLE
        val res_name=intent.getStringExtra("res_name")
        val res_id=intent.getStringExtra("res_id")
        tvResName.text="Ordering from $res_name"
        cartToolbar=findViewById(R.id.cartToolbar)
        setSupportActionBar(cartToolbar)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        itemList=CartData(applicationContext).execute().get()
        var total=0
        if(!itemList.isEmpty())
        {
            for (i in 0 until itemList.size)
            {
                total+=itemList[i].foodPrice.toInt()
            }
            btnOrderPlace.visibility=View.VISIBLE
            btnOrderPlace.text="place order ( Total Rs. $total )"
            val cartAdapter=CartAdapter(this@CartActivity,itemList)
            cartRecyclerView.adapter=cartAdapter
            cartRecyclerView.layoutManager=layoutManager
        }
        else{
            emptyCart.visibility=View.VISIBLE
            btnOrderPlace.visibility=View.INVISIBLE
        }



        btnOrderPlace.setOnClickListener {
            val sharedPreferences=getSharedPreferences(getString(R.string.preference_file), Context.MODE_PRIVATE)
            val queue= Volley.newRequestQueue(this@CartActivity)
            val url="http://13.235.250.119/v2/place_order/fetch_result/"
            val param=JSONObject()
            param.put("user_id",sharedPreferences.getString("user_id",null))
            param.put("restaurant_id",res_id?.toString())
            param.put("total_cost",total.toString())
            val params=JSONArray()
            for (i in 0 until itemList.size)
            {
                val paramobj=JSONObject()
                paramobj.put("food_item_id",itemList[i].cart_food_id.toString())
                params.put(paramobj)
            }
            param.put("food",params)


            val jsonObjectRequest=object : JsonObjectRequest(
                Method.POST,url,param,
                Response.Listener {
                    //println("response is $it")
                    val data=it.getJSONObject("data")
                    val success=data.getBoolean("success")
                    if (success)
                    {
                        orderLayout.visibility=View.VISIBLE
                        RestaurentDetails.CartData(applicationContext).execute().get()
                        Toast.makeText(this@CartActivity,"order placed successfully!!", Toast.LENGTH_SHORT).show()

                    }
                    else
                    {
                        Toast.makeText(this@CartActivity,"some error occured,try again later", Toast.LENGTH_SHORT).show()

                    }

                },
                Response.ErrorListener {
                    Toast.makeText(this@CartActivity,"some error occured,try again later", Toast.LENGTH_SHORT).show()


                }){
                override fun getHeaders():MutableMap<String,String>
                {
                    val headers=HashMap<String,String>()
                    headers["Content-type"]="application/json"
                    headers["token"]="4c90c79eae1fe0"
                    return headers
                }
            }

            queue.add(jsonObjectRequest)


        }
        btnOrderOk.setOnClickListener {
            val toHomeIntent= Intent(this@CartActivity,WelcomeActivity::class.java)
            startActivity(toHomeIntent)
            this@CartActivity.finish()
        }


    }

    class CartData(val context: Context):AsyncTask<Void,Void,List<CartEntities>>() {
        val db= Room.databaseBuilder(context,FoodDatabase::class.java,"cart-db").build()
        override fun doInBackground(vararg params: Void?): List<CartEntities>? {
            val list=db.cartDao().getAllCart()
            return list

        }
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (item.itemId==android.R.id.home)
        {
           onBackPressed()
        }

        return super.onOptionsItemSelected(item)
    }



}

