package com.sandy.chilli_souce.fragments


import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.sandy.chilli_souce.R


class MyProfileFragment : Fragment() {

    lateinit var txtName:TextView
    lateinit var txtAddress:TextView
    lateinit var txtEmail:TextView
    lateinit var txtPhoneno:TextView
    lateinit var txtUseId:TextView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view =inflater.inflate(R.layout.fragment_my_profile, container, false)

        txtName= view.findViewById(R.id.txtname)
        txtAddress= view.findViewById(R.id.txtaddress)
        txtEmail= view.findViewById(R.id.txtemail)
        txtPhoneno= view.findViewById(R.id.txtphoneno)
        txtUseId=view.findViewById(R.id.tvUserId)
        sharedPreferences=context!!.getSharedPreferences(getString(R.string.preference_file),
            Context.MODE_PRIVATE)

        txtName.text=sharedPreferences.getString("name",null)
        txtAddress.text=sharedPreferences.getString("address",null)
        txtEmail.text=sharedPreferences.getString("email",null)
        txtPhoneno.text=sharedPreferences.getString("mobile_number",null)
        txtUseId.text=sharedPreferences.getString("user_id",null)


        return view
    }


}
