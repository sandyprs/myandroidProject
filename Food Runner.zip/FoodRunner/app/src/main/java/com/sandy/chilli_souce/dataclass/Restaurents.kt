package com.sandy.chilli_souce.dataclass

data class Restaurents(val foodId:String,
                       val foodName:String,
                       val price:String,
                       val rating:String,

                       val image:String)