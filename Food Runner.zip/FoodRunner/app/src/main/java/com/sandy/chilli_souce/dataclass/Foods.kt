package com.sandy.chilli_souce.dataclass

data class Foods(val foodId:String,
                    val foodName:String,
                    val foodPrice:String,
                    val restaurantId:String)