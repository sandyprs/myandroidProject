package com.sandy.chilli_souce.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.dataclass.OrderFoodList
import com.sandy.chilli_souce.dataclass.OrderList
import kotlinx.android.synthetic.main.child_recycler.view.*
import org.json.JSONArray

class OrderHistoryAdaptor(val context: Context,val orderList:ArrayList<OrderList>) :RecyclerView.Adapter<OrderHistoryAdaptor.OrderHistoryViewHoder>(){

    class OrderHistoryViewHoder(val view:View):RecyclerView.ViewHolder(view)
    {
        var tvRestaurantName:TextView=view.findViewById(R.id.tvRestaurantName)
        var tvDate:TextView=view.findViewById(R.id.tvdate)
        var menuRecycler:RecyclerView=view.findViewById(R.id.menuRecycler)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderHistoryViewHoder {
        val view=LayoutInflater.from(context).inflate(R.layout.child_recycler,parent,false)
        return OrderHistoryViewHoder(view)
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    override fun onBindViewHolder(holder: OrderHistoryViewHoder, position: Int) {
        val data=orderList[position]
        holder.tvRestaurantName.text=data.resname
        holder.tvDate.text=data.orderDate
        setUpChildREcycler(holder.menuRecycler,data.foodItems,context)
    }

    fun setUpChildREcycler(recyclerView: RecyclerView,foodItems:JSONArray,context: Context)
    {
        val foodItemList= arrayListOf<OrderFoodList>()
        for(i in 0 until foodItems.length())
        {
            val jsonFood=foodItems.getJSONObject(i)
            val food=OrderFoodList(jsonFood.getString("food_item_id"),
            jsonFood.getString("name"),jsonFood.getString("cost"))
            foodItemList.add(food)
        }
        val foodListAdapter=FoodListAdapter(context,foodItemList)
        val childLayoutManager=LinearLayoutManager(context)
        recyclerView.layoutManager=childLayoutManager
        recyclerView.adapter=foodListAdapter




    }

}