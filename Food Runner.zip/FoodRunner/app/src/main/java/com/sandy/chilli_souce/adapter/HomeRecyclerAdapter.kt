package com.sandy.chilli_souce.adapter

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.activities.RestaurentDetails
import com.sandy.chilli_souce.database.FoodDatabase
import com.sandy.chilli_souce.database.FoodEntities
import com.sandy.chilli_souce.dataclass.Restaurents
import com.squareup.picasso.Picasso
import java.util.*
import kotlin.collections.ArrayList

class HomeRecyclerAdapter (val context:Context,val itemList:ArrayList<Restaurents>): RecyclerView.Adapter<HomeRecyclerAdapter.HomeviewHolder>(),Filterable{

    var filteredListFull=ArrayList<Restaurents>(itemList)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeviewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.recycler_home_single_row,parent,false)


        return HomeviewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }


    override fun onBindViewHolder(holder: HomeviewHolder, position: Int) {
        val foods=itemList[position]
        holder.foodId=foods.foodId.toInt()
        holder.tvFoodName.text=foods.foodName
        holder.tvFoodPrice.text="Rs. "+foods.price
        holder.tvFoodRating.text=foods.rating
        Picasso.get().load(foods.image).into(holder.imgFood)
        val foodEntities=FoodEntities(foods.foodId.toInt(),foods.foodName,foods.price,foods.rating,foods.image)
        if (DbAsyncTask(context,foodEntities,1).execute().get())
        {
            holder.btnaddFav.setBackgroundResource(R.drawable.ic_select_fav)

        }

        else{
            holder.btnaddFav.setBackgroundResource(R.drawable.ic_favorites)

        }

        holder.relativeBtn.setOnClickListener{
            val restaturentDetailsIntent= Intent(context,RestaurentDetails::class.java)
            restaturentDetailsIntent.putExtra("restaurant_id",holder.foodId.toString())
            restaturentDetailsIntent.putExtra("restaurant_name",foods.foodName)
            context.startActivity(restaturentDetailsIntent)
        }




        holder.btnaddFav.setOnClickListener{
           if (!DbAsyncTask(context,foodEntities,1).execute().get())
           {
               val async=DbAsyncTask(context,foodEntities,2).execute()
               if (async.get())
               {
                   Toast.makeText(context,"Added to Favorites",Toast.LENGTH_SHORT).show()
                   holder.btnaddFav.setBackgroundResource(R.drawable.ic_select_fav)
               }

               else{

                   Toast.makeText(context,"Some Error Occured at Insertion",Toast.LENGTH_SHORT).show()
               }


           }

           else{
               val async=DbAsyncTask(context,foodEntities,3).execute()
               if (async.get())
               {
                   Toast.makeText(context,"Removed From Favorites",Toast.LENGTH_SHORT).show()
                   holder.btnaddFav.setBackgroundResource(R.drawable.ic_favorites)
               }

               else{

                   Toast.makeText(context,"Some Error Occured at Removing",Toast.LENGTH_SHORT).show()
               }

           }

       }

    }

    class HomeviewHolder(view: View):RecyclerView.ViewHolder(view)
    {
        var foodId:Int=-1
        val tvFoodName:TextView=view.findViewById(R.id.tvFoodName)
        val tvFoodPrice:TextView=view.findViewById(R.id.tvPrice)
        val tvFoodRating:TextView=view.findViewById(R.id.tvRating)
        val imgFood:ImageView=view.findViewById(R.id.imgfood)
        val btnaddFav:TextView=view.findViewById(R.id.addFav)
        val relativeBtn:RelativeLayout=view.findViewById(R.id.tvRelativeLayout)


    }

    class DbAsyncTask(val context: Context,val foodEntities: FoodEntities,val mode:Int):AsyncTask<Void,Void,Boolean>() {

        override fun doInBackground(vararg params: Void?): Boolean {
            val db=Room.databaseBuilder(context,FoodDatabase::class.java,"foods-db").build()
            when(mode)
            {
                1 -> {

                    val isPresent:FoodEntities?=db.foodDao().getById(foodEntities.food_id.toString())
                    db.close()

                    return isPresent!=null
                }

                2->{
                    db.foodDao().foodInsert(foodEntities)
                    db.close()
                    return true

                }

                3->{
                    db.foodDao().foodDelete(foodEntities)
                    db.close()
                    return true

                }

            }
           return false
        }

    }

    override fun getFilter(): Filter {
        return newFilteredList
    }

    var newFilteredList=object :Filter(){
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val tempFilteredList=ArrayList<Restaurents>()
            if (constraint==null || constraint.length==0)
            {
                tempFilteredList.addAll(filteredListFull)
            }
            else {
                val pattern = constraint.toString().toLowerCase(Locale.ROOT).trim()
                for (item in filteredListFull)
               {
                   if(item.foodName.contains(pattern,true))
                   {
                       tempFilteredList.add(item)
                   }
               }
            }

            val filterResults=FilterResults()
            filterResults.values=tempFilteredList
            return filterResults
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                itemList.clear()
                itemList.addAll(results?.values as ArrayList<Restaurents>)
                notifyDataSetChanged()
        }

    }

}

