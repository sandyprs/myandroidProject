package com.sandy.chilli_souce.adapter

import android.content.Context
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sandy.chilli_souce.R
import com.sandy.chilli_souce.database.CartEntities
import com.sandy.chilli_souce.database.FoodDatabase
import com.sandy.chilli_souce.dataclass.Foods


class Descriptionadapter(val context:Context,val itemList:List<Foods>) :RecyclerView.Adapter<Descriptionadapter.DescriptionViewHolder>(){


    class DescriptionViewHolder(val view: View):RecyclerView.ViewHolder(view)
    {
        val itemId:TextView=view.findViewById(R.id.itemId)
        val itemName:TextView=view.findViewById(R.id.itemName)
        val btntocart:Button=view.findViewById(R.id.btntoCart)
        val itemPrice:TextView=view.findViewById(R.id.itemPrice)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DescriptionViewHolder {
        val view=LayoutInflater.from(context).inflate(R.layout.single_row_description,parent,false)
        return DescriptionViewHolder(view)
    }
    override fun getItemCount(): Int {
       return itemList.size
    }

    override fun onBindViewHolder(holder: DescriptionViewHolder, position: Int) {
        val data=itemList[position]
        holder.itemId.text=data.foodId
        holder.itemName.text=data.foodName
        holder.itemPrice.text="Rs. "+data.foodPrice
        holder.btntocart.text="+"
        val cartEntities=CartEntities(data.foodId.toInt(),data.foodName,data.foodPrice,data.restaurantId)

        holder.btntocart.setOnClickListener {

            if(!CartAsynctask(context,cartEntities,1).execute().get())
            {
                Toast.makeText(context,"added to cart",Toast.LENGTH_SHORT).show()
                holder.btntocart.text="-"
                holder.btntocart.setBackgroundResource(R.color.favColor)
                CartAsynctask(context,cartEntities,2).execute().get()

            }
            else
            {
                Toast.makeText(context,"Removed from cart",Toast.LENGTH_SHORT).show()
                holder.btntocart.text="+"
                holder.btntocart.setBackgroundResource(R.color.colorAccent)
                CartAsynctask(context,cartEntities,3).execute().get()

            }
        }
    }

    class CartAsynctask(val context: Context,val cartData:CartEntities,val mode:Int):AsyncTask<Void,Void,Boolean>() {
        override fun doInBackground(vararg params: Void?): Boolean {
            val db=Room.databaseBuilder(context,FoodDatabase::class.java,"cart-db").build()

            when(mode)
            {
                1 ->{
                    val isPresnt=db.cartDao().getById(cartData.cart_food_id.toString())
                    return isPresnt!=null
                }

                2 ->{
                    db.cartDao().cartInsert(cartData)
                    return true
                }

                3 ->{
                    db.cartDao().cartDelete(cartData)
                    return true
                }
            }


            return false

        }
    }


}